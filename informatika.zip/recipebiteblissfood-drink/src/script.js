class SpaghettiCarbonara {

  constructor() {

    this.bahan = ["spaghetti", "smoked beef", "margarin", "parmesan"];

    this.caraMemasak = ["rebus spaghetti", "tumis beef", "campur margarin dan parmesan"];

  }

  tampilkanResep() {

    console.log("Bahan:1/2") bungkus pasta spaghetti.

1 siung bawang putih.

Butter atau margarin untuk menumis.

275 mililiter susu cair putih.

1 bonggol bawang bombai ukuran sedang.

Garam.

1/2 sdt merica bubuk.

5 lembar smoked beef., this.bahan);

    console.log("Cara Memasak:"1. didihkan air lebih dahulu dan beri sedikit garam dan minyak

   2.lalu masukan spaghetti dan masak hingga al dente lalu tiriskan.

 3. lelehkan margarin atau butter ,tumis. Bawanh putih dan bombai yang sudah kamu rajang halus.

 4.masukan smoked beef, tumis hingga harus, tambahkan susu, keju parut, garam dan merica.

   setelah mendidih masuka tepung dan aduk cepat, masukan pasta ke dalam saud lalu aduk dengan api sebentar hingga saus meresap dan tidak berkuah lagi, dan spaghetti carbonara beef siap dihidangkan., this.caraMemasak);

  }


const resep = new SpaghettiCarbonara();

resep.tampilkanResep();